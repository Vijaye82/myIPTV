package com.example.myiptv

import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Accent, background = Bg, surface = Bg)) {
                Root()
            }
        }
    }
}

@Composable
fun Root(vm: IptvViewModel = viewModel()) {
    Surface(Modifier.fillMaxSize(), color = Bg) {
        when (vm.screen) {
            Screen.Settings -> SettingsScreen(vm)
            Screen.Loading -> LoadingScreen(vm)
            Screen.Browse -> BrowseScreen(vm)
            Screen.SeriesDetail -> SeriesDetailScreen(vm)
            Screen.Player -> PlayerScreen(vm)
        }
    }
}
