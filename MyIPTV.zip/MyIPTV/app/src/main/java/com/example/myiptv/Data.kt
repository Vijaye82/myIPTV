package com.example.myiptv

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

data class Category(val id: String, val name: String)

/** archiveDays > 0 means the provider keeps catch-up (TV archive) for that many days. */
data class Channel(val id: String, val name: String, val categoryId: String, val archiveDays: Int = 0)

data class Library(val categories: List<Category>, val channels: List<Channel>)

data class Vod(val id: String, val name: String, val categoryId: String, val ext: String, val rating: String)

data class Series(val id: String, val name: String, val categoryId: String, val plot: String)

data class Episode(val id: String, val season: Int, val number: Int, val title: String, val ext: String)

/** One guide entry. Times are Unix seconds; startRaw is the provider's own "yyyy-MM-dd HH:mm:ss". */
data class Programme(val title: String, val start: Long, val end: Long, val startRaw: String = "")

enum class Load { Idle, Loading, Done, Error }

enum class Kind { Live, Vod }

/** Anything the player can play. urls are tried in order until one works. */
data class PlayItem(
    val title: String,
    val subtitle: String,
    val urls: List<String>,
    val kind: Kind,
    val channel: Channel? = null,
)

fun List<Programme>.nowNext(): Pair<Programme?, Programme?> {
    val t = System.currentTimeMillis() / 1000
    return firstOrNull { t >= it.start && t < it.end } to firstOrNull { it.start > t }
}

fun hm(seconds: Long): String =
    SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(seconds * 1000))

fun dayTime(seconds: Long): String =
    SimpleDateFormat("EEE d MMM  HH:mm", Locale.getDefault()).format(Date(seconds * 1000))

fun clock(ms: Long): String {
    val s = (ms / 1000).coerceAtLeast(0)
    return if (s >= 3600) "%d:%02d:%02d".format(s / 3600, (s % 3600) / 60, s % 60)
    else "%d:%02d".format(s / 60, s % 60)
}

fun megabytes(bytes: Long): String =
    if (bytes >= 1_000_000_000) "%.1f GB".format(bytes / 1e9) else "${bytes / 1_000_000} MB"

/** Timeshift start stamp "yyyy-MM-dd:HH-mm", using the provider's own clock when we have it. */
fun Programme.archiveStamp(): String {
    val parts = startRaw.trim().split(" ")
    if (parts.size >= 2 && parts[1].length >= 5) {
        return parts[0] + ":" + parts[1].substring(0, 5).replace(':', '-')
    }
    return SimpleDateFormat("yyyy-MM-dd:HH-mm", Locale.US).format(Date(start * 1000))
}

/** Turns "myhost.com:8080/" or "http://myhost.com/player_api.php" into "http://myhost.com:8080". */
fun normaliseServer(raw: String): String {
    var s = raw.trim()
    if (s.isEmpty()) return ""
    if (!s.contains("://")) s = "http://$s"
    s = s.substringBefore("?").trimEnd('/')
    for (suffix in listOf("/player_api.php", "/get.php", "/panel_api.php")) {
        s = s.removeSuffix(suffix)
    }
    return s.trimEnd('/')
}

/** One playlist (provider login). */
data class Config(
    val id: String = UUID.randomUUID().toString(),
    val name: String = "",
    val username: String = "",
    val password: String = "",
    val primary: String = "",
    val backups: List<String> = listOf("", "", ""),
) {
    /** Primary first, then backups, normalised, blanks and duplicates removed. */
    val servers: List<String>
        get() = (listOf(primary) + backups).map(::normaliseServer).filter { it.isNotEmpty() }.distinct()

    val isComplete: Boolean
        get() = username.isNotBlank() && password.isNotBlank() && servers.isNotEmpty()
}

class Store(context: Context) {
    private val prefs: SharedPreferences = try {
        val key = MasterKey.Builder(context).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
        EncryptedSharedPreferences.create(
            context,
            "iptv_secure",
            key,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM,
        )
    } catch (e: Exception) {
        // Some boxes have a flaky keystore; fall back so the app still works.
        context.getSharedPreferences("iptv_plain", Context.MODE_PRIVATE)
    }

    // ---- Playlists ----------------------------------------------------------

    fun profiles(): List<Config> {
        val raw = prefs.getString("profiles", null)
        if (raw != null) {
            return try {
                val arr = JSONArray(raw)
                (0 until arr.length()).map { i ->
                    val o = arr.getJSONObject(i)
                    val b = o.optJSONArray("backups")
                    Config(
                        id = o.optString("id"),
                        name = o.optString("name"),
                        username = o.optString("user"),
                        password = o.optString("pass"),
                        primary = o.optString("primary"),
                        backups = (0..2).map { b?.optString(it, "") ?: "" },
                    )
                }
            } catch (e: Exception) {
                emptyList()
            }
        }
        // Migrate the single login saved by earlier versions.
        val user = prefs.getString("user", "") ?: ""
        if (user.isBlank()) return emptyList()
        val migrated = Config(
            name = "Playlist 1",
            username = user,
            password = prefs.getString("pass", "") ?: "",
            primary = prefs.getString("primary", "") ?: "",
            backups = (1..3).map { prefs.getString("backup$it", "") ?: "" },
        )
        saveProfiles(listOf(migrated))
        return listOf(migrated)
    }

    fun saveProfiles(list: List<Config>) {
        val arr = JSONArray()
        list.forEach { c ->
            arr.put(
                JSONObject()
                    .put("id", c.id)
                    .put("name", c.name.trim())
                    .put("user", c.username.trim())
                    .put("pass", c.password)
                    .put("primary", c.primary.trim())
                    .put("backups", JSONArray(c.backups.map { it.trim() })),
            )
        }
        prefs.edit().putString("profiles", arr.toString()).apply()
    }

    fun activeId(): String? = prefs.getString("active", null)
    fun setActive(id: String) = prefs.edit().putString("active", id).apply()

    // ---- Per-playlist favourites and recents --------------------------------

    private fun ids(key: String): List<String> =
        (prefs.getString(key, "") ?: "").split(",").filter { it.isNotEmpty() }

    fun favourites(profileId: String): Set<String> = ids("favs_$profileId").toSet()
    fun saveFavourites(profileId: String, s: Set<String>) =
        prefs.edit().putString("favs_$profileId", s.joinToString(",")).apply()

    fun recents(profileId: String): List<String> = ids("recents_$profileId")
    fun saveRecents(profileId: String, l: List<String>) =
        prefs.edit().putString("recents_$profileId", l.joinToString(",")).apply()
}
