package com.example.myiptv

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Environment
import android.os.IBinder
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.setValue
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Records a live stream by saving the raw MPEG-TS feed to a file.
 * Recordings live in the app's own movie folder, so no storage permission is needed.
 */
object Recorder {

    class Active(val channelId: String, val name: String, val file: File, val stopAt: Long?) {
        var bytes by mutableLongStateOf(0L)

        @Volatile var stopRequested = false

        @Volatile var conn: HttpURLConnection? = null
    }

    val active = mutableStateListOf<Active>()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    fun isRecording(channelId: String) = active.any { it.channelId == channelId }

    fun dir(ctx: Context): File {
        val d = ctx.getExternalFilesDir(Environment.DIRECTORY_MOVIES) ?: File(ctx.filesDir, "recordings")
        d.mkdirs()
        return d
    }

    fun files(ctx: Context): List<File> =
        (dir(ctx).listFiles() ?: emptyArray()).filter { it.isFile && it.name.endsWith(".ts") }
            .sortedByDescending { it.lastModified() }

    /** Starts recording; stops by itself at [stopAt] (epoch millis) or when [stop] is called. */
    fun start(ctx: Context, channelId: String, name: String, urls: List<String>, stopAt: Long?) {
        if (urls.isEmpty() || isRecording(channelId)) return
        val app = ctx.applicationContext
        val stamp = SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(Date())
        val safe = name.replace(Regex("[^A-Za-z0-9]+"), "_").trim('_').take(40).ifEmpty { "channel" }
        val a = Active(channelId, name, File(dir(app), "${safe}_$stamp.ts"), stopAt)
        active.add(a)
        try {
            ContextCompat.startForegroundService(app, Intent(app, RecordingService::class.java))
        } catch (e: Exception) {
            // Recording still runs while the app is open even if the service can't start.
        }
        scope.launch {
            try {
                record(a, urls)
            } finally {
                active.remove(a)
                if (a.bytes == 0L) a.file.delete()
                if (active.isEmpty()) app.stopService(Intent(app, RecordingService::class.java))
            }
        }
    }

    fun stop(channelId: String) {
        active.firstOrNull { it.channelId == channelId }?.let { a ->
            a.stopRequested = true
            scope.launch { a.conn?.disconnect() }
        }
    }

    private fun shouldRun(a: Active): Boolean {
        val limit = a.stopAt
        return !a.stopRequested && (limit == null || System.currentTimeMillis() < limit)
    }

    private fun record(a: Active, urls: List<String>) {
        var idx = 0
        var fails = 0
        val buf = ByteArray(64 * 1024)
        FileOutputStream(a.file, true).use { out ->
            while (shouldRun(a)) {
                var c: HttpURLConnection? = null
                var got = 0L
                try {
                    c = URL(urls[idx % urls.size]).openConnection() as HttpURLConnection
                    c.connectTimeout = 8_000
                    c.readTimeout = 15_000
                    c.setRequestProperty("User-Agent", "MyIPTV/1.0")
                    a.conn = c
                    if (c.responseCode !in 200..299) throw IOException("HTTP ${c.responseCode}")
                    c.inputStream.use { input ->
                        while (shouldRun(a)) {
                            val n = input.read(buf)
                            if (n < 0) break
                            out.write(buf, 0, n)
                            a.bytes += n
                            got += n
                        }
                    }
                } catch (e: Exception) {
                    if (a.stopRequested) break
                } finally {
                    c?.disconnect()
                }
                if (got > 0) {
                    fails = 0
                } else {
                    // Nothing received: move on to the next server, give up after two full rounds.
                    idx++
                    fails++
                    if (fails >= urls.size * 2) break
                    Thread.sleep(2_000)
                }
            }
        }
    }
}

/** Keeps the process alive while a recording runs. */
class RecordingService : Service() {
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (Build.VERSION.SDK_INT >= 26) {
            getSystemService(NotificationManager::class.java).createNotificationChannel(
                NotificationChannel("rec", "Recording", NotificationManager.IMPORTANCE_LOW),
            )
        }
        val n: Notification = NotificationCompat.Builder(this, "rec")
            .setContentTitle("MyIPTV is recording")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setOngoing(true)
            .build()
        ServiceCompat.startForeground(this, 1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        return START_NOT_STICKY
    }
}
