package com.example.myiptv

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.delay

@Composable
fun PlayerScreen(vm: IptvViewModel) {
    val item = vm.playing ?: return
    val live = item.kind == Kind.Live
    val channel = item.channel
    val urls = item.urls
    val context = LocalContext.current

    var attempt by remember(item) { mutableIntStateOf(0) }
    var status by remember(item) { mutableStateOf("Loading...") }
    var showInfo by remember(item) { mutableStateOf(true) }
    var note by remember(item) { mutableStateOf("") }
    var pos by remember { mutableLongStateOf(0L) }
    var dur by remember { mutableLongStateOf(0L) }

    val player = remember { ExoPlayer.Builder(context).build() }
    DisposableEffect(Unit) { onDispose { player.release() } }

    LifecycleEventEffect(Lifecycle.Event.ON_STOP) { player.pause() }
    LifecycleEventEffect(Lifecycle.Event.ON_START) { player.playWhenReady = true }

    LaunchedEffect(item) { if (channel != null) vm.loadEpg(channel) }

    // (Re)start playback whenever the item or the attempt number changes.
    LaunchedEffect(item, attempt) {
        if (attempt >= urls.size) {
            status = if (live) "Channel unavailable on all servers" else "Couldn't play this"
            return@LaunchedEffect
        }
        status = if (attempt == 0) "Loading..." else "Stream failed - trying alternative (${attempt + 1}/${urls.size})..."
        player.setMediaItem(MediaItem.fromUri(urls[attempt]))
        player.prepare()
        player.playWhenReady = true
    }

    // On any playback error, fall through to the next URL.
    DisposableEffect(player, item) {
        val listener = object : Player.Listener {
            override fun onPlayerError(error: PlaybackException) {
                attempt += 1
            }

            override fun onPlaybackStateChanged(state: Int) {
                if (state == Player.STATE_READY) status = ""
            }
        }
        player.addListener(listener)
        onDispose { player.removeListener(listener) }
    }

    // Banner auto-hides after a few seconds (stays up while a film is paused).
    LaunchedEffect(item, showInfo) {
        if (showInfo) {
            delay(5_000)
            if (live || player.isPlaying) showInfo = false
        }
    }

    // Progress ticker for films, episodes, catch-up and recordings.
    LaunchedEffect(item, showInfo) {
        while (showInfo && !live) {
            pos = player.currentPosition
            dur = player.duration.takeIf { it > 0 } ?: 0L
            delay(500)
        }
    }

    BackHandler { vm.stop() }

    val focus = remember { FocusRequester() }
    LaunchedEffect(Unit) { focus.requestFocus() }

    fun seek(deltaMs: Long) {
        player.seekTo((player.currentPosition + deltaMs).coerceAtLeast(0))
        showInfo = true
    }

    fun toggleRecording(ch: Channel) {
        if (Recorder.isRecording(ch.id)) {
            Recorder.stop(ch.id)
            note = "Recording stopped"
        } else {
            val prog = (vm.epg[ch.id] ?: emptyList()).nowNext().first
            val stopAt = prog?.let { it.end * 1000 + 120_000 } ?: (System.currentTimeMillis() + 3_600_000)
            Recorder.start(context, ch.id, ch.name, vm.tsUrls(ch), stopAt)
            note = if (prog != null) "Recording until the end of ${prog.title}" else "Recording for 1 hour"
        }
        showInfo = true
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(Color.Black)
            .focusRequester(focus)
            .focusable()
            .onPreviewKeyEvent { e ->
                if (e.type != KeyEventType.KeyDown) return@onPreviewKeyEvent false
                if (live && channel != null) {
                    when (e.key) {
                        Key.DirectionUp, Key.ChannelUp -> { vm.step(-1); showInfo = true; true }
                        Key.DirectionDown, Key.ChannelDown -> { vm.step(1); showInfo = true; true }
                        Key.DirectionLeft -> { toggleRecording(channel); true }
                        Key.DirectionRight -> {
                            vm.toggleFavourite(channel)
                            note = if (channel.id in vm.favourites) "Added to favourites" else "Removed from favourites"
                            showInfo = true
                            true
                        }
                        Key.DirectionCenter, Key.Enter, Key.NumPadEnter -> { showInfo = true; true }
                        else -> false
                    }
                } else {
                    when (e.key) {
                        Key.DirectionLeft, Key.MediaRewind -> { seek(-10_000); true }
                        Key.DirectionRight, Key.MediaFastForward -> { seek(10_000); true }
                        Key.DirectionCenter, Key.Enter, Key.NumPadEnter, Key.MediaPlayPause -> {
                            player.playWhenReady = !player.playWhenReady
                            showInfo = true
                            true
                        }
                        Key.MediaPlay -> { player.playWhenReady = true; showInfo = true; true }
                        Key.MediaPause -> { player.playWhenReady = false; showInfo = true; true }
                        Key.DirectionUp, Key.DirectionDown -> { showInfo = true; true }
                        else -> false
                    }
                }
            },
    ) {
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { ctx ->
                PlayerView(ctx).apply {
                    useController = false
                    isFocusable = false
                    isFocusableInTouchMode = false
                    resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
                    this.player = player
                }
            },
        )

        if (live && channel != null && Recorder.isRecording(channel.id)) {
            Text(
                "● REC",
                color = Color(0xFFFF5A5A),
                style = MaterialTheme.typography.titleMedium,
                modifier = Modifier.align(Alignment.TopEnd).padding(32.dp),
            )
        }

        if (showInfo || status.isNotEmpty()) {
            Column(
                Modifier
                    .align(Alignment.BottomStart)
                    .padding(32.dp)
                    .widthIn(max = 640.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0xCC000000))
                    .padding(horizontal = 20.dp, vertical = 14.dp),
            ) {
                Text(item.title, style = MaterialTheme.typography.titleLarge, color = Color.White, maxLines = 1)
                if (item.subtitle.isNotEmpty()) Text(item.subtitle, color = Color.White, maxLines = 1)
                if (status.isNotEmpty()) {
                    Text(status, style = MaterialTheme.typography.bodyMedium, color = Color(0xFFFFC857))
                } else if (live && channel != null) {
                    if (note.isNotEmpty()) Text(note, color = Color(0xFF7FD99A))
                    val (now, next) = (vm.epg[channel.id] ?: emptyList()).nowNext()
                    now?.let { p ->
                        Text("${hm(p.start)}  ${p.title}", color = Color.White, maxLines = 1)
                        val total = (p.end - p.start).coerceAtLeast(1)
                        val done = (System.currentTimeMillis() / 1000 - p.start).coerceIn(0, total)
                        LinearProgressIndicator(
                            progress = { done.toFloat() / total },
                            modifier = Modifier.width(360.dp).padding(vertical = 6.dp),
                        )
                    }
                    next?.let { Text("Next ${hm(it.start)}  ${it.title}", color = Dim, maxLines = 1) }
                    Text(
                        "${vm.activeLabel}  -  Up/Down: channel  -  Left: record  -  Right: favourite",
                        style = MaterialTheme.typography.bodySmall,
                        color = Dim,
                    )
                } else {
                    LinearProgressIndicator(
                        progress = { if (dur > 0) (pos.toFloat() / dur).coerceIn(0f, 1f) else 0f },
                        modifier = Modifier.width(360.dp).padding(vertical = 6.dp),
                    )
                    Text(
                        "${clock(pos)} / ${if (dur > 0) clock(dur) else "--:--"}   -   OK: pause   Left/Right: skip 10s",
                        style = MaterialTheme.typography.bodySmall,
                        color = Dim,
                    )
                }
            }
        }
    }
}
