package com.example.myiptv

import android.app.Application
import android.net.Uri
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import java.io.File
import java.io.IOException
import java.net.ConnectException
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import java.util.UUID

enum class Screen { Settings, Loading, Browse, SeriesDetail, Player }

enum class Section(val label: String) {
    Home("Home"),
    Live("Live TV"),
    Movies("Movies"),
    Series("TV Series"),
    Guide("Guide"),
    Catchup("Catch-up"),
    Favourites("Favourites"),
    Recordings("Recordings"),
}

class IptvViewModel(app: Application) : AndroidViewModel(app) {

    private val store = Store(app)

    // ---- Playlists --------------------------------------------------------------

    var profiles by mutableStateOf(store.profiles()); private set
    var activeId by mutableStateOf(store.activeId()?.takeIf { id -> profiles.any { it.id == id } }
        ?: profiles.firstOrNull()?.id ?: UUID.randomUUID().toString()); private set

    val config: Config get() = profiles.firstOrNull { it.id == activeId } ?: Config(id = activeId)

    // ---- Navigation and status ------------------------------------------------------

    var screen by mutableStateOf(Screen.Settings); private set
    private var returnTo = Screen.Browse
    var section by mutableStateOf(Section.Home)
    var status by mutableStateOf(""); private set
    var error by mutableStateOf<String?>(null); private set

    // ---- Live TV ----------------------------------------------------------------------

    var activeServer by mutableStateOf<String?>(null); private set
    var categories by mutableStateOf<List<Category>>(emptyList()); private set
    var channels by mutableStateOf<List<Channel>>(emptyList()); private set
    var selectedCategory by mutableStateOf<String?>(null)
    var query by mutableStateOf("")

    var favourites by mutableStateOf(store.favourites(activeId)); private set
    private var recentIds by mutableStateOf(store.recents(activeId))

    /** Channel currently highlighted in the browser (drives the hero banner). */
    var focused by mutableStateOf<Channel?>(null)

    val epg = mutableStateMapOf<String, List<Programme>>()
    private val epgSlots = Semaphore(4)
    private val epgInFlight = mutableSetOf<String>()

    val visible: List<Channel> by derivedStateOf {
        val cat = selectedCategory
        val q = query.trim()
        channels.filter { (cat == null || it.categoryId == cat) && (q.isEmpty() || it.name.contains(q, ignoreCase = true)) }
    }

    val favChannels: List<Channel> by derivedStateOf { channels.filter { it.id in favourites } }

    val recentChannels: List<Channel> by derivedStateOf {
        val byId = channels.associateBy { it.id }
        recentIds.mapNotNull { byId[it] }
    }

    // ---- Movies ----------------------------------------------------------------------

    var vodLoad by mutableStateOf(Load.Idle); private set
    var vodError by mutableStateOf<String?>(null); private set
    var vodCategories by mutableStateOf<List<Category>>(emptyList()); private set
    var vodItems by mutableStateOf<List<Vod>>(emptyList()); private set
    var vodCategory by mutableStateOf<String?>(null)
    var vodQuery by mutableStateOf("")

    val vodVisible: List<Vod> by derivedStateOf {
        val cat = vodCategory
        val q = vodQuery.trim()
        vodItems.filter { (cat == null || it.categoryId == cat) && (q.isEmpty() || it.name.contains(q, ignoreCase = true)) }
    }

    // ---- TV series -----------------------------------------------------------------

    var seriesLoad by mutableStateOf(Load.Idle); private set
    var seriesError by mutableStateOf<String?>(null); private set
    var seriesCategories by mutableStateOf<List<Category>>(emptyList()); private set
    var seriesItems by mutableStateOf<List<Series>>(emptyList()); private set
    var seriesCategory by mutableStateOf<String?>(null)
    var seriesQuery by mutableStateOf("")

    val seriesVisible: List<Series> by derivedStateOf {
        val cat = seriesCategory
        val q = seriesQuery.trim()
        seriesItems.filter { (cat == null || it.categoryId == cat) && (q.isEmpty() || it.name.contains(q, ignoreCase = true)) }
    }

    var detail by mutableStateOf<Series?>(null); private set
    var episodes by mutableStateOf<List<Episode>>(emptyList()); private set
    var episodesLoad by mutableStateOf(Load.Idle); private set
    var episodesError by mutableStateOf<String?>(null); private set
    var season by mutableIntStateOf(1)

    // ---- Catch-up -------------------------------------------------------------------

    var catchupChannel by mutableStateOf<Channel?>(null); private set
    var catchupList by mutableStateOf<List<Programme>>(emptyList()); private set
    var catchupLoad by mutableStateOf(Load.Idle); private set
    var catchupError by mutableStateOf<String?>(null); private set

    // ---- Playback state ---------------------------------------------------------------

    var playing by mutableStateOf<PlayItem?>(null); private set
    private var playList: List<Channel> = emptyList()

    /** "Primary server", "Backup server 2", ... for the server currently in use. */
    val activeLabel: String
        get() {
            val idx = config.servers.indexOf(activeServer)
            return when {
                idx < 0 -> ""
                idx == 0 -> "Primary server"
                else -> "Backup server $idx"
            }
        }

    init {
        if (config.isComplete) connect()
    }

    // ---- Settings and playlists ------------------------------------------------------

    fun openSettings() {
        error = null
        screen = Screen.Settings
    }

    fun cancelSettings() {
        screen = if (channels.isNotEmpty()) Screen.Browse else Screen.Settings
    }

    /** Saves (or adds) a playlist, makes it the active one and connects. */
    fun saveProfile(p: Config) {
        profiles = if (profiles.any { it.id == p.id }) profiles.map { if (it.id == p.id) p else it } else profiles + p
        store.saveProfiles(profiles)
        switchTo(p.id)
    }

    fun deleteProfile(id: String) {
        profiles = profiles.filter { it.id != id }
        store.saveProfiles(profiles)
        if (activeId != id) return
        val next = profiles.firstOrNull()
        if (next != null) {
            switchTo(next.id)
        } else {
            activeId = UUID.randomUUID().toString()
            resetLibrary()
            screen = Screen.Settings
        }
    }

    private fun switchTo(id: String) {
        activeId = id
        store.setActive(id)
        favourites = store.favourites(id)
        recentIds = store.recents(id)
        resetLibrary()
        connect()
    }

    private fun resetLibrary() {
        categories = emptyList()
        channels = emptyList()
        activeServer = null
        selectedCategory = null
        query = ""
        focused = null
        epg.clear()
        resetLazy()
    }

    private fun resetLazy() {
        vodLoad = Load.Idle; vodItems = emptyList(); vodCategories = emptyList(); vodCategory = null; vodQuery = ""
        seriesLoad = Load.Idle; seriesItems = emptyList(); seriesCategories = emptyList(); seriesCategory = null; seriesQuery = ""
        detail = null
        catchupChannel = null
    }

    // ---- Connecting with failover ----------------------------------------------------

    fun connect() {
        val cfg = config
        if (!cfg.isComplete) {
            error = "Enter a username, password and at least a primary URL."
            screen = Screen.Settings
            return
        }
        screen = Screen.Loading
        error = null
        viewModelScope.launch {
            val servers = cfg.servers
            val problems = mutableListOf<String>()
            for ((i, server) in servers.withIndex()) {
                status = if (i == 0) "Connecting to primary server..."
                else "Trying backup $i of ${servers.size - 1}..."
                try {
                    val lib = withContext(Dispatchers.IO) { Iptv.load(server, cfg) }
                    activeServer = server
                    categories = lib.categories
                    channels = lib.channels
                    selectedCategory = null
                    query = ""
                    focused = null
                    epg.clear()
                    resetLazy()
                    screen = Screen.Browse
                    return@launch
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    val name = if (i == 0) "Primary" else "Backup $i"
                    problems += "$name: ${friendly(e)}"
                }
            }
            error = problems.joinToString("\n")
        }
    }

    private fun friendly(e: Exception): String = when (e) {
        is UnknownHostException -> "can't find that address"
        is SocketTimeoutException -> "timed out"
        is ConnectException -> "connection refused"
        is IOException -> e.message ?: "network error"
        else -> e.message ?: e.javaClass.simpleName
    }

    private fun orderedServers(): List<String> =
        listOfNotNull(activeServer) + config.servers.filter { it != activeServer }

    private fun userPath(): String = "${Uri.encode(config.username)}/${Uri.encode(config.password)}"

    /** Runs a request on the working server first, then the others. Remembers whichever answers. */
    private suspend fun <T> onServers(block: (String) -> T): T {
        var last: Exception? = null
        for (s in orderedServers()) {
            try {
                val r = withContext(Dispatchers.IO) { block(s) }
                activeServer = s
                return r
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                last = e
            }
        }
        throw last ?: IOException("No server available")
    }

    // ---- Favourites and guide ---------------------------------------------------------

    fun toggleFavourite(ch: Channel) {
        favourites = if (ch.id in favourites) favourites - ch.id else favourites + ch.id
        store.saveFavourites(activeId, favourites)
    }

    /** Fetches now/next for a channel once; at most 4 requests run at the same time. */
    fun loadEpg(ch: Channel) {
        if (epg.containsKey(ch.id) || !epgInFlight.add(ch.id)) return
        val server = activeServer ?: run { epgInFlight.remove(ch.id); return }
        val cfg = config
        viewModelScope.launch {
            try {
                val list = epgSlots.withPermit {
                    withContext(Dispatchers.IO) { Iptv.shortEpg(server, cfg, ch.id) }
                }
                epg[ch.id] = list
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                epg[ch.id] = emptyList()
            } finally {
                epgInFlight.remove(ch.id)
            }
        }
    }

    // ---- Movies and series loading ---------------------------------------------------

    fun loadVod() {
        if (vodLoad == Load.Loading || vodLoad == Load.Done) return
        vodLoad = Load.Loading
        val cfg = config
        viewModelScope.launch {
            try {
                val (cats, items) = onServers { Iptv.loadVod(it, cfg) }
                vodCategories = cats
                vodItems = items
                vodLoad = Load.Done
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                vodError = friendly(e)
                vodLoad = Load.Error
            }
        }
    }

    fun reloadVod() {
        vodLoad = Load.Idle
        loadVod()
    }

    fun loadSeries() {
        if (seriesLoad == Load.Loading || seriesLoad == Load.Done) return
        seriesLoad = Load.Loading
        val cfg = config
        viewModelScope.launch {
            try {
                val (cats, items) = onServers { Iptv.loadSeries(it, cfg) }
                seriesCategories = cats
                seriesItems = items
                seriesLoad = Load.Done
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                seriesError = friendly(e)
                seriesLoad = Load.Error
            }
        }
    }

    fun reloadSeries() {
        seriesLoad = Load.Idle
        loadSeries()
    }

    fun openSeries(s: Series) {
        detail = s
        episodes = emptyList()
        episodesLoad = Load.Loading
        screen = Screen.SeriesDetail
        loadEpisodes(s)
    }

    fun loadEpisodes(s: Series) {
        episodesLoad = Load.Loading
        val cfg = config
        viewModelScope.launch {
            try {
                val list = onServers { Iptv.episodes(it, cfg, s.id) }
                episodes = list
                season = list.minOfOrNull { it.season } ?: 1
                episodesLoad = Load.Done
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                episodesError = friendly(e)
                episodesLoad = Load.Error
            }
        }
    }

    fun closeSeries() {
        detail = null
        screen = Screen.Browse
    }

    // ---- Catch-up ----------------------------------------------------------------------

    fun openCatchup(ch: Channel) {
        catchupChannel = ch
        catchupList = emptyList()
        catchupLoad = Load.Loading
        val cfg = config
        viewModelScope.launch {
            try {
                catchupList = onServers { Iptv.catchup(it, cfg, ch.id, ch.archiveDays) }
                catchupLoad = Load.Done
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                catchupError = friendly(e)
                catchupLoad = Load.Error
            }
        }
    }

    fun closeCatchup() {
        catchupChannel = null
    }

    // ---- Playback -----------------------------------------------------------------------

    private fun launchPlayer(item: PlayItem) {
        if (screen != Screen.Player) returnTo = screen
        playing = item
        screen = Screen.Player
    }

    /** Every URL worth trying for a live channel: working server first, each as HLS then TS. */
    fun candidates(ch: Channel): List<String> = orderedServers().flatMap { s ->
        val base = "$s/live/${userPath()}/${ch.id}"
        listOf("$base.m3u8", "$base.ts")
    }

    /** Raw transport-stream URLs, used for recording. */
    fun tsUrls(ch: Channel): List<String> = orderedServers().map { "$it/live/${userPath()}/${ch.id}.ts" }

    private fun liveItem(ch: Channel) = PlayItem(ch.name, "", candidates(ch), Kind.Live, ch)

    fun play(ch: Channel, list: List<Channel> = visible) {
        playList = list
        noteRecent(ch)
        launchPlayer(liveItem(ch))
    }

    private fun noteRecent(ch: Channel) {
        recentIds = (listOf(ch.id) + recentIds.filter { it != ch.id }).take(20)
        store.saveRecents(activeId, recentIds)
    }

    fun step(delta: Int) {
        val list = playList.ifEmpty { visible }
        val current = playing?.channel ?: return
        val i = list.indexOfFirst { it.id == current.id }
        if (i < 0 || list.isEmpty()) return
        val next = list[(i + delta).mod(list.size)]
        noteRecent(next)
        playing = liveItem(next)
    }

    fun playMovie(v: Vod) {
        val urls = orderedServers().map { "$it/movie/${userPath()}/${v.id}.${v.ext}" }
        launchPlayer(PlayItem(v.name, "", urls, Kind.Vod))
    }

    fun playEpisode(s: Series, e: Episode) {
        val urls = orderedServers().map { "$it/series/${userPath()}/${e.id}.${e.ext}" }
        launchPlayer(PlayItem(s.name, "S${e.season} E${e.number}  ${e.title}", urls, Kind.Vod))
    }

    fun playCatchup(ch: Channel, p: Programme) {
        val minutes = (((p.end - p.start) + 59) / 60).coerceAtLeast(1)
        val urls = orderedServers().map { "$it/timeshift/${userPath()}/$minutes/${p.archiveStamp()}/${ch.id}.ts" }
        launchPlayer(PlayItem(ch.name, "${dayTime(p.start)}  ${p.title}", urls, Kind.Vod))
    }

    fun playRecording(f: File) {
        val title = f.nameWithoutExtension.replace('_', ' ')
        launchPlayer(PlayItem(title, "Recording", listOf(Uri.fromFile(f).toString()), Kind.Vod))
    }

    fun stop() {
        playing = null
        screen = returnTo
    }
}
