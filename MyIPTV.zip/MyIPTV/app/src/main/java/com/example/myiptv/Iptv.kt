package com.example.myiptv

import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/** Minimal client for the Xtream-Codes style `player_api.php` interface. */
object Iptv {

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    private fun http(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 8_000
        c.readTimeout = 30_000
        c.instanceFollowRedirects = true
        c.setRequestProperty("User-Agent", "MyIPTV/1.0")
        try {
            if (c.responseCode !in 200..299) error("HTTP ${c.responseCode}")
            return c.inputStream.bufferedReader().use { it.readText() }
        } finally {
            c.disconnect()
        }
    }

    private fun api(server: String, cfg: Config, action: String? = null): String =
        "$server/player_api.php?username=${enc(cfg.username)}&password=${enc(cfg.password)}" +
            (action?.let { "&action=$it" } ?: "")

    private fun jsonArray(url: String): JSONArray {
        val raw = http(url).trim()
        if (!raw.startsWith("[")) error("This playlist doesn't provide that section")
        return JSONArray(raw)
    }

    private fun categories(server: String, cfg: Config, action: String): List<Category> {
        val arr = jsonArray(api(server, cfg, action))
        return (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            Category(o.optString("category_id"), o.optString("category_name"))
        }
    }

    private fun decode(raw: String): String = try {
        String(Base64.decode(raw, Base64.DEFAULT), Charsets.UTF_8)
    } catch (e: Exception) {
        raw
    }

    /** Logs in and downloads the live channel list from one server. Throws on any problem. */
    fun load(server: String, cfg: Config): Library {
        val auth = JSONObject(http(api(server, cfg)))
        val info = auth.optJSONObject("user_info") ?: error("Unexpected reply (is this the right URL?)")
        if (info.optString("auth") != "1") error("Login rejected - check username and password")
        val status = info.optString("status")
        if (status.isNotEmpty() && !status.equals("Active", ignoreCase = true)) {
            error("Account status: $status")
        }

        val cats = categories(server, cfg, "get_live_categories")
        val arr = jsonArray(api(server, cfg, "get_live_streams"))
        val channels = (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            val archive = o.optString("tv_archive") == "1"
            Channel(
                id = o.optString("stream_id"),
                name = o.optString("name").ifBlank { "Channel ${o.optString("stream_id")}" },
                categoryId = o.optString("category_id"),
                archiveDays = if (archive) o.optInt("tv_archive_duration", 1).coerceAtLeast(1) else 0,
            )
        }
        if (channels.isEmpty()) error("Logged in, but the channel list is empty")
        return Library(cats, channels)
    }

    // ---- Movies -------------------------------------------------------------

    fun loadVod(server: String, cfg: Config): Pair<List<Category>, List<Vod>> {
        val cats = categories(server, cfg, "get_vod_categories")
        val arr = jsonArray(api(server, cfg, "get_vod_streams"))
        val items = (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            Vod(
                id = o.optString("stream_id"),
                name = o.optString("name").ifBlank { "Movie" },
                categoryId = o.optString("category_id"),
                ext = o.optString("container_extension").ifBlank { "mp4" },
                rating = o.optString("rating"),
            )
        }
        return cats to items
    }

    // ---- TV series ----------------------------------------------------------

    fun loadSeries(server: String, cfg: Config): Pair<List<Category>, List<Series>> {
        val cats = categories(server, cfg, "get_series_categories")
        val arr = jsonArray(api(server, cfg, "get_series"))
        val items = (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            Series(
                id = o.optString("series_id"),
                name = o.optString("name").ifBlank { "Series" },
                categoryId = o.optString("category_id"),
                plot = o.optString("plot"),
            )
        }
        return cats to items
    }

    fun episodes(server: String, cfg: Config, seriesId: String): List<Episode> {
        val root = JSONObject(http(api(server, cfg, "get_series_info") + "&series_id=${enc(seriesId)}"))
        val eps = root.opt("episodes")
        val seasons: List<Pair<Int, JSONArray>> = when (eps) {
            is JSONObject -> eps.keys().asSequence().mapNotNull { k ->
                eps.optJSONArray(k)?.let { (k.toIntOrNull() ?: 0) to it }
            }.toList()
            is JSONArray -> (0 until eps.length()).mapNotNull { i ->
                eps.optJSONArray(i)?.let { (i + 1) to it }
            }
            else -> emptyList()
        }
        val out = mutableListOf<Episode>()
        for ((season, arr) in seasons) {
            for (i in 0 until arr.length()) {
                val e = arr.optJSONObject(i) ?: continue
                out += Episode(
                    id = e.optString("id"),
                    season = season,
                    number = e.optInt("episode_num", i + 1),
                    title = e.optString("title").ifBlank { "Episode ${i + 1}" },
                    ext = e.optString("container_extension").ifBlank { "mp4" },
                )
            }
        }
        return out.sortedWith(compareBy({ it.season }, { it.number }))
    }

    // ---- Guide and catch-up -------------------------------------------------

    private fun parseProgramme(e: JSONObject): Programme? {
        val start = e.optString("start_timestamp").toLongOrNull() ?: return null
        val end = e.optString("stop_timestamp").toLongOrNull() ?: return null
        return Programme(
            title = decode(e.optString("title")).ifBlank { "Programme" },
            start = start,
            end = end,
            startRaw = e.optString("start"),
        )
    }

    /** Now/next guide data for one channel (empty if the provider has none). */
    fun shortEpg(server: String, cfg: Config, streamId: String): List<Programme> {
        val url = api(server, cfg, "get_short_epg") + "&stream_id=${enc(streamId)}&limit=3"
        val arr = JSONObject(http(url)).optJSONArray("epg_listings") ?: return emptyList()
        return (0 until arr.length()).mapNotNull { parseProgramme(arr.getJSONObject(it)) }.sortedBy { it.start }
    }

    /** Past programmes that the provider still has archived, newest first. */
    fun catchup(server: String, cfg: Config, streamId: String, days: Int): List<Programme> {
        val url = api(server, cfg, "get_simple_data_table") + "&stream_id=${enc(streamId)}"
        val arr = JSONObject(http(url)).optJSONArray("epg_listings") ?: return emptyList()
        val now = System.currentTimeMillis() / 1000
        val oldest = now - days * 86_400L
        return (0 until arr.length()).mapNotNull {
            val o = arr.getJSONObject(it)
            if (o.optInt("has_archive", 1) == 0) null else parseProgramme(o)
        }.filter { it.end < now && it.start > oldest }.sortedByDescending { it.start }
    }
}
