package com.example.myiptv

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items as gridItems
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import java.util.UUID

val Bg = Color(0xFF080B14)
val Panel = Color(0xFF131A2B)
val Accent = Color(0xFF4F8CFF)
val Dim = Color(0xFFA7B0C5)
private val Gold = Color(0xFFFFC857)
private val Red = Color(0xFFFF7A7A)

// ---------------------------------------------------------------------------
// Building blocks
// ---------------------------------------------------------------------------

/** A full-width, D-pad friendly button that lights up when focused. */
@Composable
fun FocusItem(text: String, onClick: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    Box(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(if (focused) Accent else Color.Transparent)
            .onFocusChanged { focused = it.isFocused }
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 12.dp),
    ) {
        Text(text, color = Color.White, maxLines = 1, style = MaterialTheme.typography.bodyLarge)
    }
}

/** A pill used for the top tabs and category filters. */
@Composable
fun Chip(text: String, selected: Boolean = false, onClick: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    Box(
        Modifier
            .clip(RoundedCornerShape(50))
            .background(
                when {
                    focused -> Accent
                    selected -> Color(0xFF2A3350)
                    else -> Panel
                },
            )
            .onFocusChanged { focused = it.isFocused }
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 9.dp),
    ) {
        Text(text, color = Color.White, maxLines = 1, style = MaterialTheme.typography.bodyMedium)
    }
}

/** A list row with text on the left and a dimmer note on the right. */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun FocusRow(left: String, right: String = "", onLongClick: (() -> Unit)? = null, onClick: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(if (focused) Accent else Color.Transparent)
            .onFocusChanged { focused = it.isFocused }
            .combinedClickable(onClick = onClick, onLongClick = onLongClick)
            .padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(left, color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
        if (right.isNotEmpty()) {
            Text(right, color = if (focused) Color.White else Dim, maxLines = 1)
        }
    }
}

private fun tileColor(name: String): Color =
    Color.hsv(((name.hashCode() and 0x7fffffff) % 360).toFloat(), 0.55f, 0.45f)

/** Generic poster/channel tile. OK = onClick, holding OK = onLongClick. */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun Tile(
    title: String,
    modifier: Modifier = Modifier,
    subtitle: String = "",
    star: Boolean = false,
    onFocus: () -> Unit = {},
    onLongClick: (() -> Unit)? = null,
    onClick: () -> Unit,
) {
    var focused by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(if (focused) 1.08f else 1f, label = "tileScale")
    val shape = RoundedCornerShape(10.dp)
    Box(
        modifier
            .aspectRatio(16f / 9f)
            .scale(scale)
            .clip(shape)
            .background(Brush.linearGradient(listOf(tileColor(title), Color(0xFF0E1424))))
            .border(if (focused) 3.dp else 0.dp, if (focused) Color.White else Color.Transparent, shape)
            .onFocusChanged {
                focused = it.isFocused
                if (it.isFocused) onFocus()
            }
            .combinedClickable(onClick = onClick, onLongClick = onLongClick)
            .padding(10.dp),
    ) {
        Column(Modifier.align(Alignment.BottomStart)) {
            Text(
                title,
                color = Color.White,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.SemiBold,
            )
            if (subtitle.isNotEmpty()) {
                Text(subtitle, color = Dim, maxLines = 1, style = MaterialTheme.typography.bodySmall)
            }
        }
        if (star) Text("★", color = Gold, modifier = Modifier.align(Alignment.TopEnd))
    }
}

@Composable
fun ChannelTile(ch: Channel, vm: IptvViewModel, modifier: Modifier = Modifier, onPlay: () -> Unit) {
    Tile(
        title = ch.name,
        modifier = modifier,
        subtitle = if (ch.archiveDays > 0) "Catch-up" else "",
        star = ch.id in vm.favourites,
        onFocus = { vm.focused = ch; vm.loadEpg(ch) },
        onLongClick = { vm.toggleFavourite(ch) },
        onClick = onPlay,
    )
}

/** Banner at the top of a page describing whichever channel is highlighted. */
@Composable
fun Hero(vm: IptvViewModel) {
    val ch = vm.focused
    Column(
        Modifier
            .fillMaxWidth()
            .height(110.dp)
            .padding(horizontal = 48.dp),
        verticalArrangement = Arrangement.Center,
    ) {
        if (ch == null) {
            Text("What's on", style = MaterialTheme.typography.headlineSmall, color = Color.White)
            Text("OK to watch  -  hold OK to add a favourite", color = Dim)
        } else {
            val (now, next) = (vm.epg[ch.id] ?: emptyList()).nowNext()
            Text(ch.name, style = MaterialTheme.typography.headlineSmall, color = Color.White, maxLines = 1)
            Text(
                now?.let { "Now  ${hm(it.start)}-${hm(it.end)}  ${it.title}" } ?: "No guide information",
                color = Color.White,
                maxLines = 1,
            )
            next?.let { Text("Next  ${hm(it.start)}  ${it.title}", color = Dim, maxLines = 1) }
        }
    }
}

@Composable
fun CategoryChips(
    categories: List<Category>,
    selected: String?,
    onSelect: (String?) -> Unit,
    modifier: Modifier = Modifier,
) {
    LazyRow(
        modifier,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        contentPadding = PaddingValues(vertical = 6.dp),
    ) {
        item { Chip("All", selected == null) { onSelect(null) } }
        items(categories) { c -> Chip(c.name, selected == c.id) { onSelect(c.id) } }
    }
}

/** Search box + category chips, shared by Live TV, Movies and TV Series. */
@Composable
private fun FilterBar(
    query: String,
    onQuery: (String) -> Unit,
    categories: List<Category>,
    selected: String?,
    onSelect: (String?) -> Unit,
) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 48.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        OutlinedTextField(
            value = query,
            onValueChange = onQuery,
            singleLine = true,
            placeholder = { Text("Search") },
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
            modifier = Modifier.width(300.dp),
        )
        CategoryChips(categories, selected, onSelect, Modifier.weight(1f))
    }
}

/** Shows a spinner / error with retry / the content, depending on the load state. */
@Composable
private fun LoadGate(load: Load, error: String?, onRetry: () -> Unit, content: @Composable () -> Unit) {
    when (load) {
        Load.Idle, Load.Loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator(color = Accent)
        }
        Load.Error -> Column(Modifier.fillMaxSize().padding(48.dp)) {
            Text("Couldn't load this: ${error ?: "unknown error"}", color = Red)
            Spacer(Modifier.height(16.dp))
            Box(Modifier.width(240.dp)) { FocusItem("Retry", onRetry) }
        }
        Load.Done -> content()
    }
}

// ---------------------------------------------------------------------------
// Browse screen: top bar + sections
// ---------------------------------------------------------------------------

@Composable
fun BrowseScreen(vm: IptvViewModel) {
    Column(Modifier.fillMaxSize().background(Bg)) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 48.dp, vertical = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Text("MyIPTV", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = Color.White)
            LazyRow(Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(Section.values().toList()) { s -> Chip(s.label, vm.section == s) { vm.section = s } }
            }
            Column(horizontalAlignment = Alignment.End) {
                Text(vm.config.name.ifBlank { "Playlist" }, color = Color.White, style = MaterialTheme.typography.bodySmall)
                Text(vm.activeLabel, color = Color(0xFF7FD99A), style = MaterialTheme.typography.bodySmall)
            }
            Chip("Settings") { vm.openSettings() }
        }
        Box(Modifier.weight(1f)) {
            when (vm.section) {
                Section.Home -> HomeSection(vm)
                Section.Live -> LiveSection(vm)
                Section.Movies -> MoviesSection(vm)
                Section.Series -> SeriesSection(vm)
                Section.Guide -> GuideSection(vm)
                Section.Catchup -> CatchupSection(vm)
                Section.Favourites -> FavouritesSection(vm)
                Section.Recordings -> RecordingsSection(vm)
            }
        }
    }
}

@Composable
private fun Rail(title: String, items: List<Channel>, vm: IptvViewModel) {
    if (items.isEmpty()) return
    Text(
        title,
        style = MaterialTheme.typography.titleMedium,
        color = Color.White,
        modifier = Modifier.padding(start = 48.dp, top = 12.dp),
    )
    LazyRow(
        contentPadding = PaddingValues(horizontal = 48.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        items(items) { ch -> ChannelTile(ch, vm, Modifier.width(200.dp)) { vm.play(ch, items) } }
    }
}

@Composable
private fun HomeSection(vm: IptvViewModel) {
    val rails = remember(vm.channels, vm.categories) {
        vm.categories.take(8).map { cat ->
            cat.name to vm.channels.filter { it.categoryId == cat.id }.take(40)
        }
    }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Hero(vm)
        Rail("Continue watching", vm.recentChannels, vm)
        Rail("Favourites", vm.favChannels, vm)
        rails.forEach { (name, list) -> Rail(name, list, vm) }
    }
}

@Composable
private fun LiveSection(vm: IptvViewModel) {
    Column(Modifier.fillMaxSize()) {
        Hero(vm)
        FilterBar(vm.query, { vm.query = it }, vm.categories, vm.selectedCategory) { vm.selectedCategory = it }
        ChannelGrid(vm, vm.visible, Modifier.weight(1f))
    }
}

@Composable
private fun FavouritesSection(vm: IptvViewModel) {
    Column(Modifier.fillMaxSize()) {
        Hero(vm)
        if (vm.favChannels.isEmpty()) {
            Text(
                "No favourites yet. Hold OK on any channel to add it.",
                color = Dim,
                modifier = Modifier.padding(horizontal = 48.dp, vertical = 24.dp),
            )
        } else {
            ChannelGrid(vm, vm.favChannels, Modifier.weight(1f))
        }
    }
}

@Composable
private fun ChannelGrid(vm: IptvViewModel, list: List<Channel>, modifier: Modifier) {
    LazyVerticalGrid(
        columns = GridCells.Adaptive(190.dp),
        modifier = modifier,
        contentPadding = PaddingValues(horizontal = 48.dp, vertical = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        gridItems(list) { ch -> ChannelTile(ch, vm, Modifier.fillMaxWidth()) { vm.play(ch, list) } }
    }
}

// ---- Movies and TV series ----------------------------------------------------

private fun ratingText(r: String): String =
    r.toDoubleOrNull()?.takeIf { it > 0 }?.let { "★ $r" } ?: ""

@Composable
private fun MoviesSection(vm: IptvViewModel) {
    LaunchedEffect(Unit) { vm.loadVod() }
    LoadGate(vm.vodLoad, vm.vodError, { vm.reloadVod() }) {
        val list = vm.vodVisible
        Column(Modifier.fillMaxSize()) {
            FilterBar(vm.vodQuery, { vm.vodQuery = it }, vm.vodCategories, vm.vodCategory) { vm.vodCategory = it }
            if (list.isEmpty()) {
                Text("No movies found.", color = Dim, modifier = Modifier.padding(48.dp))
            } else {
                LazyVerticalGrid(
                    columns = GridCells.Adaptive(190.dp),
                    modifier = Modifier.weight(1f),
                    contentPadding = PaddingValues(horizontal = 48.dp, vertical = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp),
                ) {
                    gridItems(list) { v ->
                        Tile(v.name, Modifier.fillMaxWidth(), subtitle = ratingText(v.rating)) { vm.playMovie(v) }
                    }
                }
            }
        }
    }
}

@Composable
private fun SeriesSection(vm: IptvViewModel) {
    LaunchedEffect(Unit) { vm.loadSeries() }
    LoadGate(vm.seriesLoad, vm.seriesError, { vm.reloadSeries() }) {
        val list = vm.seriesVisible
        Column(Modifier.fillMaxSize()) {
            FilterBar(vm.seriesQuery, { vm.seriesQuery = it }, vm.seriesCategories, vm.seriesCategory) { vm.seriesCategory = it }
            if (list.isEmpty()) {
                Text("No series found.", color = Dim, modifier = Modifier.padding(48.dp))
            } else {
                LazyVerticalGrid(
                    columns = GridCells.Adaptive(190.dp),
                    modifier = Modifier.weight(1f),
                    contentPadding = PaddingValues(horizontal = 48.dp, vertical = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp),
                ) {
                    gridItems(list) { s -> Tile(s.name, Modifier.fillMaxWidth()) { vm.openSeries(s) } }
                }
            }
        }
    }
}

@Composable
fun SeriesDetailScreen(vm: IptvViewModel) {
    BackHandler { vm.closeSeries() }
    val s = vm.detail ?: return
    Column(Modifier.fillMaxSize().background(Bg).padding(horizontal = 48.dp, vertical = 24.dp)) {
        Text(s.name, style = MaterialTheme.typography.headlineMedium, color = Color.White, maxLines = 2)
        if (s.plot.isNotBlank()) {
            Text(s.plot, color = Dim, maxLines = 3, overflow = TextOverflow.Ellipsis)
        }
        Spacer(Modifier.height(12.dp))
        LoadGate(vm.episodesLoad, vm.episodesError, { vm.loadEpisodes(s) }) {
            val seasons = vm.episodes.map { it.season }.distinct().sorted()
            if (seasons.isEmpty()) {
                Text("No episodes available.", color = Dim)
            } else {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(seasons) { n -> Chip("Season $n", vm.season == n) { vm.season = n } }
                }
                Spacer(Modifier.height(8.dp))
                LazyColumn(Modifier.fillMaxSize()) {
                    items(vm.episodes.filter { it.season == vm.season }) { e ->
                        FocusRow("E${e.number}  ${e.title}") { vm.playEpisode(s, e) }
                    }
                }
            }
        }
    }
}

// ---- Guide, catch-up, recordings ---------------------------------------------------

@Composable
private fun GuideSection(vm: IptvViewModel) {
    val list = vm.visible
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 48.dp)) {
            CategoryChips(vm.categories, vm.selectedCategory, { vm.selectedCategory = it }, Modifier.weight(1f))
        }
        LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(vertical = 8.dp)) {
            items(list) { ch -> GuideRow(ch, vm, list) }
        }
    }
}

@Composable
private fun GuideRow(ch: Channel, vm: IptvViewModel, list: List<Channel>) {
    LaunchedEffect(ch.id) { vm.loadEpg(ch) }
    var focused by remember { mutableStateOf(false) }
    val (now, next) = (vm.epg[ch.id] ?: emptyList()).nowNext()
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 48.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(if (focused) Accent else Color.Transparent)
            .onFocusChanged { focused = it.isFocused }
            .clickable { vm.play(ch, list) }
            .padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(ch.name, color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.width(300.dp))
        Text(
            now?.let { "${hm(it.start)}  ${it.title}" } ?: "-",
            color = Color.White,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f),
        )
        Text(
            next?.let { "${hm(it.start)}  ${it.title}" } ?: "",
            color = if (focused) Color.White else Dim,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f),
        )
    }
}

@Composable
private fun CatchupSection(vm: IptvViewModel) {
    val ch = vm.catchupChannel
    BackHandler(enabled = ch != null) { vm.closeCatchup() }
    Column(Modifier.fillMaxSize().padding(horizontal = 48.dp)) {
        if (ch == null) {
            val list = remember(vm.channels) { vm.channels.filter { it.archiveDays > 0 } }
            Text("Catch-up TV", style = MaterialTheme.typography.titleLarge, color = Color.White)
            Text("Pick a channel to see programmes you can watch again.", color = Dim)
            Spacer(Modifier.height(8.dp))
            if (list.isEmpty()) {
                Text("This playlist has no catch-up channels.", color = Dim)
            } else {
                LazyColumn(Modifier.fillMaxSize()) {
                    items(list) { c -> FocusRow(c.name, "${c.archiveDays} days") { vm.openCatchup(c) } }
                }
            }
        } else {
            Text("${ch.name} - catch-up", style = MaterialTheme.typography.titleLarge, color = Color.White)
            Text("Back returns to the channel list.", color = Dim)
            Spacer(Modifier.height(8.dp))
            LoadGate(vm.catchupLoad, vm.catchupError, { vm.openCatchup(ch) }) {
                if (vm.catchupList.isEmpty()) {
                    Text("No archived programmes found for this channel.", color = Dim)
                } else {
                    LazyColumn(Modifier.fillMaxSize()) {
                        items(vm.catchupList) { p -> FocusRow(p.title, dayTime(p.start)) { vm.playCatchup(ch, p) } }
                    }
                }
            }
        }
    }
}

@Composable
private fun RecordingsSection(vm: IptvViewModel) {
    val ctx = LocalContext.current
    val active = Recorder.active
    var files by remember { mutableStateOf(Recorder.files(ctx)) }
    LaunchedEffect(active.size) { files = Recorder.files(ctx) }

    Column(Modifier.fillMaxSize().padding(horizontal = 48.dp)) {
        Text("Recordings", style = MaterialTheme.typography.titleLarge, color = Color.White)
        Text(
            "Free space: ${megabytes(Recorder.dir(ctx).usableSpace)}  -  hold OK on a recording to delete it. " +
                "Start a recording from live TV with Left.",
            color = Dim,
        )
        Spacer(Modifier.height(8.dp))
        LazyColumn(Modifier.fillMaxSize()) {
            items(active.toList()) { a ->
                FocusRow("● ${a.name}", "${megabytes(a.bytes)}  -  OK to stop") { Recorder.stop(a.channelId) }
            }
            items(files) { f ->
                FocusRow(
                    f.nameWithoutExtension.replace('_', ' '),
                    megabytes(f.length()),
                    onLongClick = {
                        f.delete()
                        files = Recorder.files(ctx)
                    },
                ) { vm.playRecording(f) }
            }
        }
    }
}

// ---------------------------------------------------------------------------
// Settings (playlists) and loading
// ---------------------------------------------------------------------------

@Composable
fun SettingsScreen(vm: IptvViewModel) {
    var editId by remember { mutableStateOf(vm.config.id) }
    val base = vm.profiles.firstOrNull { it.id == editId }
        ?: Config(id = editId, name = "Playlist ${vm.profiles.size + 1}")
    val exists = vm.profiles.any { it.id == editId }

    var name by remember(editId) { mutableStateOf(base.name) }
    var user by remember(editId) { mutableStateOf(base.username) }
    var pass by remember(editId) { mutableStateOf(base.password) }
    var primary by remember(editId) { mutableStateOf(base.primary) }
    var b1 by remember(editId) { mutableStateOf(base.backups.getOrElse(0) { "" }) }
    var b2 by remember(editId) { mutableStateOf(base.backups.getOrElse(1) { "" }) }
    var b3 by remember(editId) { mutableStateOf(base.backups.getOrElse(2) { "" }) }

    Column(
        Modifier
            .fillMaxSize()
            .background(Bg)
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 120.dp, vertical = 32.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Text("Playlists", style = MaterialTheme.typography.headlineMedium, color = Color.White)
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(vm.profiles) { p ->
                Chip(p.name.ifBlank { "Playlist" }, selected = p.id == editId) { editId = p.id }
            }
            item { Chip("+ Add playlist") { editId = UUID.randomUUID().toString() } }
        }
        Text(
            "Backups are tried in order if the primary fails. Each playlist keeps its own favourites.",
            color = Dim,
        )
        vm.error?.let { Text(it, color = Red) }

        Field("Playlist name", name, { name = it })
        Field("Username", user, { user = it })
        Field("Password", pass, { pass = it }, password = true)
        Field("Primary URL  (e.g. http://myserver.com:8080)", primary, { primary = it }, url = true)
        Field("Backup URL 1", b1, { b1 = it }, url = true)
        Field("Backup URL 2", b2, { b2 = it }, url = true)
        Field("Backup URL 3", b3, { b3 = it }, url = true, last = true)

        Spacer(Modifier.height(8.dp))
        Column(Modifier.width(320.dp)) {
            FocusItem("Save & Connect") {
                vm.saveProfile(Config(editId, name, user, pass, primary, listOf(b1, b2, b3)))
            }
            if (vm.channels.isNotEmpty()) {
                FocusItem("Reload library") { vm.connect() }
                FocusItem("Cancel") { vm.cancelSettings() }
            }
            if (exists) FocusItem("Delete this playlist") { vm.deleteProfile(editId) }
        }
    }
}

@Composable
private fun Field(
    label: String,
    value: String,
    onChange: (String) -> Unit,
    password: Boolean = false,
    url: Boolean = false,
    last: Boolean = false,
) {
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        label = { Text(label) },
        singleLine = true,
        modifier = Modifier.fillMaxWidth(),
        visualTransformation = if (password) PasswordVisualTransformation() else VisualTransformation.None,
        keyboardOptions = KeyboardOptions(
            keyboardType = when {
                password -> KeyboardType.Password
                url -> KeyboardType.Uri
                else -> KeyboardType.Text
            },
            imeAction = if (last) ImeAction.Done else ImeAction.Next,
        ),
    )
}

@Composable
fun LoadingScreen(vm: IptvViewModel) {
    Column(
        Modifier
            .fillMaxSize()
            .background(Bg)
            .padding(120.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        val err = vm.error
        if (err == null) {
            CircularProgressIndicator(color = Accent)
            Spacer(Modifier.height(20.dp))
            Text(vm.status, color = Color.White, style = MaterialTheme.typography.titleMedium)
        } else {
            Text("Couldn't connect", color = Color.White, style = MaterialTheme.typography.headlineSmall)
            Spacer(Modifier.height(12.dp))
            Text(err, color = Red)
            Spacer(Modifier.height(24.dp))
            Box(Modifier.width(260.dp)) { FocusItem("Retry") { vm.connect() } }
            Box(Modifier.width(260.dp)) { FocusItem("Edit settings") { vm.openSettings() } }
        }
    }
}
